using System.Security.Claims;
using ClimbConnect.API.Data;
using ClimbConnect.API.Dtos;
using ClimbConnect.API.Models;
using ClimbConnect.API.Services;
using Microsoft.EntityFrameworkCore;

namespace ClimbConnect.API.Extensions;

/// <summary>Endpoints für Termine (Appointments) und Teilnahme-Verwaltung.</summary>
public static class AppointmentEndpoints
{
    public static void MapAppointmentEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/api/areas/{id:int}/appointments", async (int id, bool? all, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!await db.Areas.AnyAsync(a => a.Id == id)) return Results.NotFound();

            // Standardmäßig nur zukünftige Termine; mit ?all=true auch vergangene
            var cutoff = (all == true) ? DateTime.MinValue : DateTime.UtcNow;

            // Der Endpoint ist öffentlich; ist jemand eingeloggt, wird mitgeliefert ob er teilnimmt
            int? currentUserId = int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var uid) ? uid : null;

            var appointments = await db.Appointments
                .Where(a => a.AreaId == id && a.Date >= cutoff)
                .OrderBy(a => a.Date)
                .Select(a => new
                {
                    a.Id, a.AreaId, a.CreatedByUserId, a.Title, a.Date, a.MeetingPoint, a.Description,
                    a.MinParticipants, a.MaxParticipants, a.CreatedAtUtc,
                    ParticipantCount = a.AppointmentUsers.Count,
                    IsSubscribed     = currentUserId != null && a.AppointmentUsers.Any(au => au.UserId == currentUserId)
                })
                .ToListAsync();
            return Results.Ok(appointments);
        })
        .WithName("GetAppointmentsByArea")
        .WithTags("Appointments");

                // Nächste Termine über ALLE Gebiete in einer einzigen Anfrage (für die Startseite)
        app.MapGet("/api/appointments/upcoming", async (int? limit, ClaimsPrincipal user, AppDbContext db) =>
        {
            // Standard: 10 Termine, mindestens 1, höchstens 50
            var take = Math.Clamp(limit ?? 10, 1, 50);

            // Öffentlich; ist jemand eingeloggt, wird mitgeliefert ob er teilnimmt
            int? currentUserId = int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var uid) ? uid : null;

            var appointments = await db.Appointments
                .Where(a => a.Date >= DateTime.UtcNow)
                .OrderBy(a => a.Date)
                .Take(take)
                .Select(a => new
                {
                    a.Id, a.AreaId, a.CreatedByUserId, a.Title, a.Date, a.MeetingPoint, a.Description,
                    a.MinParticipants, a.MaxParticipants, a.CreatedAtUtc,
                    AreaName         = a.Area.Name,
                    AreaLocation     = a.Area.Location,
                    ParticipantCount = a.AppointmentUsers.Count,
                    IsSubscribed     = currentUserId != null && a.AppointmentUsers.Any(au => au.UserId == currentUserId)
                })
                .ToListAsync();
            return Results.Ok(appointments);
        })
        .WithName("GetUpcomingAppointments")
        .WithTags("Appointments");

        // Eigene Termine: selbst erstellte UND beigetretene (für das Profil)
        app.MapGet("/api/appointments/me", async (bool? all, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            // Standardmäßig nur zukünftige Termine; mit ?all=true auch vergangene
            var cutoff = (all == true) ? DateTime.MinValue : DateTime.UtcNow;

            var appointments = await db.Appointments
                .Where(a => a.Date >= cutoff
                         && (a.CreatedByUserId == userId || a.AppointmentUsers.Any(au => au.UserId == userId)))
                .OrderBy(a => a.Date)
                .Select(a => new
                {
                    a.Id, a.AreaId, a.CreatedByUserId, a.Title, a.Date, a.MeetingPoint, a.Description,
                    a.MinParticipants, a.MaxParticipants, a.CreatedAtUtc,
                    AreaName         = a.Area.Name,
                    AreaLocation     = a.Area.Location,
                    ParticipantCount = a.AppointmentUsers.Count,
                    IsCreator        = a.CreatedByUserId == userId,
                    IsSubscribed     = a.AppointmentUsers.Any(au => au.UserId == userId)
                })
                .ToListAsync();
            return Results.Ok(appointments);
        })
        .WithName("GetMyAppointments")
        .WithTags("Appointments")
        .RequireAuthorization("User");
        

        app.MapGet("/api/appointments/{id:int}", async (int id, string? scale, AppDbContext db) =>
        {
            var appointment = await db.Appointments
                .Include(a => a.AppointmentUsers)
                    .ThenInclude(au => au.User)
                .FirstOrDefaultAsync(a => a.Id == id);
            if (appointment is null) return Results.NotFound();

            var targetScale    = scale ?? "french";
            var participantIds = appointment.AppointmentUsers.Select(au => au.UserId).ToList();

            // Besten Grad pro Teilnehmer direkt per DB-Query — kein vollständiges Progresses-Load
            var bestGradePerUser = await db.Progresses
                .Where(p => participantIds.Contains(p.UserId)
                         && p.Status != "Projekt"
                         && p.Route.Grade != null)
                .Select(p => new { p.UserId, p.Route.Grade })
                .ToListAsync();

            var participantRanks = bestGradePerUser
                .GroupBy(p => p.UserId)
                .Select(g => g.Max(p => GradeConversionService.Rank(p.Grade)))
                .Where(r => r >= 0)
                .ToList();

            string? avgGrade = null;
            if (participantRanks.Count > 0)
            {
                var avgRank     = (int)Math.Round(participantRanks.Average());
                var allGrades   = GradeConversionService.GetAllGrades();
                var frenchGrade = avgRank < allGrades.Count ? allGrades[avgRank] : null;
                avgGrade = GradeConversionService.Convert(frenchGrade, targetScale);
            }

            return Results.Ok(new
            {
                appointment.Id,
                appointment.AreaId,
                appointment.CreatedByUserId,
                appointment.Title,
                appointment.Date,
                appointment.MeetingPoint,
                appointment.Description,
                appointment.MinParticipants,
                appointment.MaxParticipants,
                ParticipantCount = appointment.AppointmentUsers.Count,
                AverageGrade     = avgGrade,
                Participants     = appointment.AppointmentUsers.Select(au => new
                {
                    au.UserId,
                    au.User.Username,
                    au.Comment
                })
            });
        })
        .WithName("GetAppointmentById")
        .WithTags("Appointments");

        app.MapPost("/api/areas/{id:int}/appointments", async (int id, AppointmentCreateDto dto, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            if (!await db.Areas.AnyAsync(a => a.Id == id)) return Results.NotFound();

            var currentUser = await db.Users.FindAsync(userId);
            if (currentUser is null) return Results.Unauthorized();

            var date  = AppTime.ToUtc(dto.Date);
            var error = Validate(dto.Title, date, dto.MinParticipants, dto.MaxParticipants, checkFuture: true);
            if (error is not null) return Results.BadRequest(new { error });

            var appointment = new Appointment
            {
                AreaId          = id,
                CreatedByUserId = userId,
                // Nötig: die Datenbank führt zusätzlich den Fremdschlüssel "CreatedById",
                // der nur über diese Navigation befüllt wird.
                CreatedBy       = currentUser,
                Title           = dto.Title.Trim(),
                Date            = date,
                MeetingPoint    = string.IsNullOrWhiteSpace(dto.MeetingPoint) ? null : dto.MeetingPoint.Trim(),
                Description     = string.IsNullOrWhiteSpace(dto.Description)  ? null : dto.Description.Trim(),
                MinParticipants = dto.MinParticipants,
                MaxParticipants = dto.MaxParticipants
            };

            db.Appointments.Add(appointment);
            await db.SaveChangesAsync();

            // Nur die Termin-Felder zurückgeben, nicht den Ersteller als ganze User-Entity
            return Results.Created($"/api/appointments/{appointment.Id}", new
            {
                appointment.Id, appointment.AreaId, appointment.CreatedByUserId,
                appointment.Title, appointment.Date, appointment.MeetingPoint, appointment.Description,
                appointment.MinParticipants, appointment.MaxParticipants, appointment.CreatedAtUtc
            });
        })
        .WithName("CreateAppointment")
        .WithTags("Appointments")
        .RequireAuthorization("User");

        app.MapPut("/api/appointments/{id:int}", async (int id, AppointmentUpdateDto dto, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            var appointment = await db.Appointments.FindAsync(id);
            if (appointment is null) return Results.NotFound();

            // Nur Ersteller oder Admin darf bearbeiten
            if (appointment.CreatedByUserId != userId && !user.IsInRole("admin"))
                return Results.Forbid();

            // Gleiche Prüfung wie beim Anlegen. "Nicht in der Vergangenheit" nur, wenn das Datum
            // geändert wird – sonst ließe sich ein vergangener Termin nicht mehr korrigieren.
            var date  = AppTime.ToUtc(dto.Date);
            var error = Validate(dto.Title, date, dto.MinParticipants, dto.MaxParticipants,
                                 checkFuture: date != appointment.Date);
            if (error is not null) return Results.BadRequest(new { error });

            appointment.Title           = dto.Title.Trim();
            appointment.Date            = date;
            appointment.MeetingPoint    = string.IsNullOrWhiteSpace(dto.MeetingPoint)  ? null : dto.MeetingPoint.Trim();
            appointment.Description     = string.IsNullOrWhiteSpace(dto.Description)   ? null : dto.Description.Trim();
            appointment.MinParticipants = dto.MinParticipants;
            appointment.MaxParticipants = dto.MaxParticipants;

            await db.SaveChangesAsync();
            return Results.Ok(appointment);
        })
        .WithName("UpdateAppointment")
        .WithTags("Appointments")
        .RequireAuthorization("User");

        app.MapDelete("/api/appointments/{id:int}", async (int id, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            var appointment = await db.Appointments.FindAsync(id);
            if (appointment is null) return Results.NotFound();

            // Nur Ersteller oder Admin darf löschen
            if (appointment.CreatedByUserId != userId && !user.IsInRole("admin"))
                return Results.Forbid();

            db.Appointments.Remove(appointment);
            await db.SaveChangesAsync();
            return Results.NoContent();
        })
        .WithName("DeleteAppointment")
        .WithTags("Appointments")
        .RequireAuthorization("User");

        app.MapPost("/api/appointments/{id:int}/subscribe", async (int id, AppointmentSubscribeDto dto, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            var appointment = await db.Appointments
                .Include(a => a.AppointmentUsers)
                .FirstOrDefaultAsync(a => a.Id == id);
            if (appointment is null) return Results.NotFound();

            if (appointment.AppointmentUsers.Any(au => au.UserId == userId))
                return Results.Conflict(new { error = "Du nimmst bereits an diesem Termin teil" });

            if (appointment.MaxParticipants.HasValue &&
                appointment.AppointmentUsers.Count >= appointment.MaxParticipants.Value)
                return Results.BadRequest(new { error = "Termin ist bereits voll" });

            db.AppointmentUsers.Add(new AppointmentUser
            {
                AppointmentId = id,
                UserId        = userId,
                Comment       = string.IsNullOrWhiteSpace(dto.Comment) ? null : dto.Comment.Trim()
            });
            await db.SaveChangesAsync();
            return Results.Ok(new { message = "Erfolgreich beigetreten" });
        })
        .WithName("SubscribeToAppointment")
        .WithTags("Appointments")
        .RequireAuthorization("User");

        app.MapDelete("/api/appointments/{id:int}/subscribe", async (int id, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            var subscription = await db.AppointmentUsers
                .FirstOrDefaultAsync(au => au.AppointmentId == id && au.UserId == userId);
            if (subscription is null) return Results.NotFound();
            db.AppointmentUsers.Remove(subscription);
            await db.SaveChangesAsync();
            return Results.NoContent();
        })
        .WithName("UnsubscribeFromAppointment")
        .WithTags("Appointments")
        .RequireAuthorization("User");
    }

    /// <summary>
    /// Gemeinsame Prüfung für Anlegen und Bearbeiten. Gibt die Fehlermeldung zurück
    /// oder null, wenn alles passt.
    /// </summary>
    private static string? Validate(string title, DateTime dateUtc, int? min, int? max, bool checkFuture)
    {
        if (string.IsNullOrWhiteSpace(title))
            return "Titel ist erforderlich";
        if (min.HasValue && max.HasValue && min.Value > max.Value)
            return "Minimale Teilnehmerzahl darf nicht größer als maximale Teilnehmerzahl sein";
        if (checkFuture && dateUtc < DateTime.UtcNow)
            return "Der Termin darf nicht in der Vergangenheit liegen";
        return null;
    }
}
