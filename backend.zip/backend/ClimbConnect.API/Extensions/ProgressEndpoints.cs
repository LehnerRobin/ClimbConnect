using System.Security.Claims;
using ClimbConnect.API.Data;
using ClimbConnect.API.Dtos;
using ClimbConnect.API.Models;
using Microsoft.EntityFrameworkCore;

namespace ClimbConnect.API.Extensions;

/// <summary>Endpoints für Fortschrittseinträge (Begehungen) des eingeloggten Users.</summary>
public static class ProgressEndpoints
{
    public static void MapProgressEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/api/progress/me", async (ClaimsPrincipal user, int? page, int? pageSize, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            var p  = Math.Max(1, page ?? 1);
            var ps = Math.Clamp(pageSize ?? 20, 1, 100);

            var query = db.Progresses
                .Where(e => e.UserId == userId)
                .Include(e => e.Route)
                .OrderByDescending(e => e.Date);

            var total   = await query.CountAsync();
            var entries = await query
                .Skip((p - 1) * ps)
                .Take(ps)
                .ToListAsync();

            return Results.Ok(new { Total = total, Page = p, PageSize = ps, Items = entries });
        })
        .WithName("GetMyProgress")
        .WithTags("Progress")
        .RequireAuthorization("User");

        app.MapGet("/api/progress/{id:int}", async (int id, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            var progress = await db.Progresses
                .Include(p => p.Route)
                .FirstOrDefaultAsync(p => p.Id == id);
            if (progress is null) return Results.NotFound();
            if (progress.UserId != userId) return Results.Forbid();

            return Results.Ok(progress);
        })
        .WithName("GetProgressById")
        .WithTags("Progress")
        .RequireAuthorization("User");

        app.MapPost("/api/progress", async (ProgressCreateDto dto, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            if (!ProgressConst.Statuses.Contains(dto.Status))
                return Results.BadRequest(new { error = $"Status muss einer von: {string.Join(", ", ProgressConst.Statuses)} sein" });
            if (!ProgressConst.Styles.Contains(dto.ClimbingStyle))
                return Results.BadRequest(new { error = $"Begehungsart muss einer von: {string.Join(", ", ProgressConst.Styles)} sein" });
            if (dto.Attempts < 1)
                return Results.BadRequest(new { error = "Anzahl Versuche muss mindestens 1 sein" });
            if (ProgressConst.FirstTryStatuses.Contains(dto.Status) && dto.Attempts != 1)
                return Results.BadRequest(new { error = "Bei Flash und Onsight ist die Anzahl der Versuche immer 1" });
            if (!await db.Routes.AnyAsync(r => r.Id == dto.RouteId))
                return Results.BadRequest(new { error = "Route nicht gefunden" });

            var progress = new Progress
            {
                UserId                 = userId,
                RouteId                = dto.RouteId,
                Status                 = dto.Status,
                ClimbingStyle          = dto.ClimbingStyle,
                Attempts               = dto.Attempts,
                Notes                  = string.IsNullOrWhiteSpace(dto.Notes) ? null : dto.Notes.Trim(),
                Date                   = dto.Date,
                SubjectiveGrade        = string.IsNullOrWhiteSpace(dto.SubjectiveGrade) ? null : dto.SubjectiveGrade.Trim().ToLower(),
                SubjectiveGradeComment = string.IsNullOrWhiteSpace(dto.SubjectiveGradeComment) ? null : dto.SubjectiveGradeComment.Trim()
            };
            db.Progresses.Add(progress);
            await db.SaveChangesAsync();
            return Results.Created($"/api/progress/{progress.Id}", progress);
        })
        .WithName("CreateProgress")
        .WithTags("Progress")
        .RequireAuthorization("User");

        app.MapPut("/api/progress/{id:int}", async (int id, ProgressUpdateDto dto, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            var progress = await db.Progresses.FindAsync(id);
            if (progress is null) return Results.NotFound();
            if (progress.UserId != userId) return Results.Forbid();

            if (!ProgressConst.Statuses.Contains(dto.Status))
                return Results.BadRequest(new { error = $"Status muss einer von: {string.Join(", ", ProgressConst.Statuses)} sein" });
            if (!ProgressConst.Styles.Contains(dto.ClimbingStyle))
                return Results.BadRequest(new { error = $"Begehungsart muss einer von: {string.Join(", ", ProgressConst.Styles)} sein" });
            if (dto.Attempts < 1)
                return Results.BadRequest(new { error = "Anzahl Versuche muss mindestens 1 sein" });
            if (ProgressConst.FirstTryStatuses.Contains(dto.Status) && dto.Attempts != 1)
                return Results.BadRequest(new { error = "Bei Flash und Onsight ist die Anzahl der Versuche immer 1" });

            progress.Status                 = dto.Status;
            progress.ClimbingStyle          = dto.ClimbingStyle;
            progress.Attempts               = dto.Attempts;
            progress.Notes                  = string.IsNullOrWhiteSpace(dto.Notes) ? null : dto.Notes.Trim();
            progress.Date                   = dto.Date;
            progress.SubjectiveGrade        = string.IsNullOrWhiteSpace(dto.SubjectiveGrade) ? null : dto.SubjectiveGrade.Trim().ToLower();
            progress.SubjectiveGradeComment = string.IsNullOrWhiteSpace(dto.SubjectiveGradeComment) ? null : dto.SubjectiveGradeComment.Trim();

            await db.SaveChangesAsync();
            return Results.Ok(progress);
        })
        .WithName("UpdateProgress")
        .WithTags("Progress")
        .RequireAuthorization("User");

        app.MapDelete("/api/progress/{id:int}", async (int id, ClaimsPrincipal user, AppDbContext db) =>
        {
            if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Results.Unauthorized();

            var progress = await db.Progresses.FindAsync(id);
            if (progress is null) return Results.NotFound();
            if (progress.UserId != userId) return Results.Forbid();

            db.Progresses.Remove(progress);
            await db.SaveChangesAsync();
            return Results.NoContent();
        })
        .WithName("DeleteProgress")
        .WithTags("Progress")
        .RequireAuthorization("User");
    }
}
