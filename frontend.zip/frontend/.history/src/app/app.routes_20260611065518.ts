import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
<<<<<<< HEAD

=======
217175fa5f0db4065d3497b568e236b8b3b24f05
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { canActivateAuthRole } from './guards/auth-role.guard';
import { AreasPageComponent } from './features/areas/areas-page.component';

export const routes: Routes = [
 HEAD
  { path: 'areas',  component: AreasPageComponent},
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },  
  { path: 'mdemos', component: MDemosComponent, canActivate: [canActivateAuthRole],   data: { role: 'myUserRole'}, },
  { path: 'mdemo-add', component: MDemoAddComponent, canActivate: [canActivateAuthRole],   data: { role: 'myUserRole'},  },
  { path: 'mdemo-detail/:id', component: MDemoDetailComponent, canActivate: [canActivateAuthRole],   data: { role: 'myUserRole'},  },
  { path: 'mdemo-update/:id', component: MDemoUpdateComponent, canActivate: [canActivateAuthRole],   data: { role: 'myUserRole'},  },
  { path: 'admin', component: AdminComponent, canActivate: [canActivateAuthRole],   data: { role: 'myAdminRole'},  },
{
  path: 'profile',  component: UserProfileComponent}, 


 { path: 'forbidden', component: ForbiddenComponent },
  { path: '**', redirectTo: '/home' } 
=======
  { path: '',        redirectTo: '/home', pathMatch: 'full' },
  { path: 'home',   component: HomeComponent },
  { path: 'areas',  component: AreasPageComponent },
  { path: 'admin',   component: AdminComponent,     canActivate: [canActivateAuthRole], data: { role: 'myAdminRole' } },
  { path: 'profile', component: UserProfileComponent, canActivate: [canActivateAuthRole], data: { role: 'view-profile' } },
  { path: 'forbidden', component: ForbiddenComponent },
  { path: '**', redirectTo: '/home' }
>>>>>>> 217175fa5f0db4065d3497b568e236b8b3b24f05
];
