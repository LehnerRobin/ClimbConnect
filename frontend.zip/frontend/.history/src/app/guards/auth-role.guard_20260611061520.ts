import { Routes } from '@angular/router';

import { MDemosComponent } from './mdemos/mdemos.component';
import { MDemoDetailComponent } from './mdemo.detail/mdemo.detail.component';
import { MDemoAddComponent } from './mdemo.add/mdemo.add.component';
import { MDemoUpdateComponent } from './mdemo.update/mdemo.update.component';

import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { UserProfileComponent } from './user-profile/user-profile.component';

import { AreasPageComponent } from './features/areas/areas-page.component';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },

  { path: 'home', component: HomeComponent },

  { path: 'areas', component: AreasPageComponent },

  { path: 'mdemos', component: MDemosComponent },

  { path: 'mdemo-add', component: MDemoAddComponent },

  { path: 'mdemo-detail/:id', component: MDemoDetailComponent },

  { path: 'mdemo-update/:id', component: MDemoUpdateComponent },

  { path: 'admin', component: AdminComponent },

  { path: 'profile', component: UserProfileComponent },

  { path: 'forbidden', component: ForbiddenComponent },

  { path: '**', redirectTo: '/home' }
];