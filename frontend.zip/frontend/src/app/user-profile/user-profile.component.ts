import { Component, OnInit, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AreaVisit, UserService } from '../../services/user.service';
import { Appointment, AreasService, ProgressEntry } from '../../services/areas.service';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

interface MyAppointment extends Appointment {
  areaId: number;
  areaName: string;
  areaLocation?: string | null;
}

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit, AfterViewInit {

  @ViewChild('gradeChart') gradeChartRef!: ElementRef<HTMLCanvasElement>;

  user = {
    id: 0,
    username: '',
    email: '',
    bio: '',
    preferredGradeScale: 'french',
    memberSince: ''
  };

  stats = {
    totalAscents: 0,
    openProjects: 0,
    favoriteArea: '-'
  };

  areaVisits: AreaVisit[] = [];
  /** Größte Besuchszahl – der Balken dieses Gebiets ist 100 % breit. */
  maxAreaVisits = 1;

  gradeProgression: { month: string; grade: string; rank: number }[] = [];
  chartReady = false;
  private chart: Chart | null = null;

  myProgress: ProgressEntry[] = [];
  progressError = '';
  profileError = '';
  statsError = '';
  deletingProgressId: number | null = null;
  myAppointments: MyAppointment[] = [];
  loadingAppointments = false;
  appointmentError = '';
  deletingAppointmentId: number | null = null;

  saveSuccess = false;
  saveError = '';

  passwordForm = { current: '', newPw: '', confirm: '' };
  passwordSuccess = false;
  passwordError = '';

  constructor(
    private userService: UserService,
    private areasService: AreasService
  ) {}

  ngOnInit(): void {
    this.userService.getMe().subscribe({
      next: (data) => {
        this.user.id                  = data.id;
        this.user.username            = data.username;
        this.user.email               = data.email;
        this.user.bio                 = data.bio ?? '';
        this.user.preferredGradeScale = data.preferredGradeScale ?? 'french';
        this.user.memberSince         = data.memberSince;

        this.loadStats();
        this.loadMyProgress();
        this.loadMyAppointments();
      },
      error: () => { this.profileError = 'Profil konnte nicht geladen werden. Bitte lade die Seite neu.'; }
    });
  }

  ngAfterViewInit(): void {
    this.chartReady = true;
    this.buildChart();
  }

  private loadStats(): void {
    this.userService.getStats(this.user.id, this.user.preferredGradeScale ?? 'french').subscribe({
      next: (s) => {
        this.stats.totalAscents = s.totalClimbed ?? 0;
        this.stats.openProjects = s.openProjects ?? 0;
        this.stats.favoriteArea = s.favoriteArea ?? '-';
        this.gradeProgression   = s.gradeProgression ?? [];
        this.areaVisits         = s.areaVisits ?? [];
        this.maxAreaVisits      = Math.max(1, ...this.areaVisits.map(v => v.visits));

        // Das <canvas> existiert erst, nachdem @if(gradeProgression.length > 0)
        // neu gerendert wurde. Wir warten daher einen Tick, bis Angular die
        // Änderung verarbeitet und @ViewChild('gradeChart') aufgelöst hat,
        // bevor wir versuchen den Chart darauf zu zeichnen.
        setTimeout(() => this.buildChart());
      },
      error: () => { this.statsError = 'Statistik konnte nicht geladen werden.'; }
    });
  }

  private loadMyProgress(): void {
    this.progressError = '';

    this.areasService.getMyProgress().subscribe({
      next: (progress) => { this.myProgress = progress; },
      error: () => {
        this.progressError = 'Begehungen konnten nicht geladen werden.';
      }
    });
  }

  /** Lädt eigene Termine (erstellt + beigetreten) mit einer einzigen Anfrage. */
  private loadMyAppointments(): void {
    this.loadingAppointments = true;
    this.appointmentError = '';

    this.areasService.getMyAppointments(true).subscribe({
      next: (appointments) => {
        this.myAppointments = appointments.map((appointment): MyAppointment => ({
          ...appointment,
          areaId: appointment.areaId ?? 0,
          areaName: appointment.areaName ?? '',
          areaLocation: appointment.areaLocation ?? null
        }));
        this.loadingAppointments = false;
      },
      error: () => {
        this.appointmentError = 'Eigene Termine konnten nicht geladen werden.';
        this.loadingAppointments = false;
      }
    });
  }

  deleteOwnAppointment(appointment: MyAppointment): void {
    const confirmed = window.confirm(`Termin \"${appointment.title}\" wirklich löschen?`);
    if (!confirmed) {
      return;
    }

    this.appointmentError = '';
    this.deletingAppointmentId = appointment.id;

    this.areasService.deleteAppointment(appointment.id).subscribe({
      next: () => {
        this.myAppointments = this.myAppointments.filter(item => item.id !== appointment.id);
        this.deletingAppointmentId = null;
      },
      error: (error) => {
        console.error('Appointment delete error:', error);
        this.appointmentError = error.status === 401 || error.status === 403
          ? 'Du darfst nur eigene Termine löschen.'
          : 'Termin konnte nicht gelöscht werden.';
        this.deletingAppointmentId = null;
      }
    });
  }

  deleteProgress(progress: ProgressEntry): void {
    const routeName = progress.route?.name ?? 'diese Begehung';
    const confirmed = window.confirm(`Begehung von "${routeName}" wirklich löschen?`);
    if (!confirmed) {
      return;
    }

    this.progressError = '';
    this.deletingProgressId = progress.id;

    this.areasService.deleteProgress(progress.id).subscribe({
      next: () => {
        this.myProgress = this.myProgress.filter(item => item.id !== progress.id);
        this.deletingProgressId = null;
        this.loadStats();
      },
      error: (error) => {
        console.error('Progress delete error:', error);
        this.progressError = error.status === 401 || error.status === 403
          ? 'Du darfst nur eigene Begehungen löschen.'
          : 'Begehung konnte nicht gelöscht werden.';
        this.deletingProgressId = null;
      }
    });
  }

  /**
   * Liefert eine CSS-Klasse passend zum Begehungs-Status, damit gesendete
   * Routen (Rotpunkt/Flash/Onsight) optisch von offenen Projekten und
   * reinen Toprope-Begehungen unterschieden werden können.
   */
  statusClass(status: string): string {
    switch (status) {
      case 'Rotpunkt':
      case 'Flash':
      case 'Onsight':
        return 'status-sent';
      case 'Projekt':
        return 'status-project';
      default:
        return 'status-toprope';
    }
  }

  private buildChart(): void {
    if (!this.chartReady || this.gradeProgression.length === 0) return;
    if (!this.gradeChartRef?.nativeElement) return;

    if (this.chart) {
      this.chart.destroy();
    }

    // Die Höhe eines Punkts ist der Rang des Grads (höher = schwerer). Beschriftet wird
    // die Y-Achse genau an den Rängen, die vorkommen – mit dem Grad in der Skala des Users.
    const gradeByRank = new Map(this.gradeProgression.map(p => [p.rank, p.grade]));
    const ranks = [...gradeByRank.keys()];

    this.chart = new Chart(this.gradeChartRef.nativeElement, {
      type: 'line',
      data: {
        labels: this.gradeProgression.map(p => p.month),
        datasets: [{
          label: 'Höchster Grad',
          data: this.gradeProgression.map(p => p.rank),
          borderColor: '#C3791F',
          backgroundColor: 'rgba(195, 121, 31, 0.12)',
          pointBackgroundColor: '#17150F',
          pointBorderColor: '#F7F4EB',
          pointBorderWidth: 2,
          pointHoverRadius: 7,
          tension: 0.3,
          fill: true,
          pointRadius: 5
        }]
      },
      options: {
        plugins: {
          tooltip: {
            backgroundColor: '#17150F',
            titleFont: { family: "'IBM Plex Sans', sans-serif", weight: 600 },
            bodyFont: { family: "'IBM Plex Mono', monospace" },
            padding: 10,
            cornerRadius: 8,
            callbacks: {
              label: (ctx) => this.gradeProgression[ctx.dataIndex]?.grade ?? ''
            }
          },
          legend: { display: false }
        },
        scales: {
          x: {
            grid: { color: 'rgba(23, 21, 15, 0.06)' },
            ticks: { color: '#756C53', font: { family: "'IBM Plex Sans', sans-serif", size: 12 } }
          },
          y: {
            min: Math.min(...ranks) - 1,
            max: Math.max(...ranks) + 1,
            afterBuildTicks: (axis) => {
              axis.ticks = ranks.map(value => ({ value }));
            },
            grid: { color: 'rgba(23, 21, 15, 0.06)' },
            ticks: {
              color: '#756C53',
              font: { family: "'IBM Plex Mono', monospace", size: 12 },
              callback: (value) => gradeByRank.get(Number(value)) ?? ''
            }
          }
        }
      }
    });
  }

  changePassword(): void {
    this.passwordSuccess = false;
    this.passwordError   = '';

    if (this.passwordForm.newPw !== this.passwordForm.confirm) {
      this.passwordError = 'Die neuen Passwörter stimmen nicht überein.';
      return;
    }
    if (this.passwordForm.newPw.length < 8) {
      this.passwordError = 'Das neue Passwort muss mindestens 8 Zeichen lang sein.';
      return;
    }

    this.userService.changePassword(this.passwordForm.current, this.passwordForm.newPw).subscribe({
      next: () => {
        this.passwordSuccess = true;
        this.passwordForm = { current: '', newPw: '', confirm: '' };
      },
      error: (err) => {
        this.passwordError = err?.error?.error ?? 'Passwort konnte nicht geändert werden.';
      }
    });
  }

  saveProfile(): void {
    this.saveSuccess = false;
    this.saveError   = '';

    this.userService.updateProfile({
      bio: this.user.bio || null,
      preferredGradeScale: this.user.preferredGradeScale || null
    }).subscribe({
      next: (data) => {
        this.user.bio               = data.bio ?? '';
        this.user.preferredGradeScale = data.preferredGradeScale ?? 'french';
        this.saveSuccess = true;
      },
      error: (err) => {
        this.saveError = err?.error?.error ?? 'Profil konnte nicht gespeichert werden.';
      }
    });
  }
}
